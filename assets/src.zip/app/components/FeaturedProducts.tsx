import { useState } from "react";
import { ShoppingCart, Heart, Eye, Star, ArrowRight, Flame, Sparkles, TrendingUp, Check } from "lucide-react";
import { useCart } from "../context/CartContext";
import { ALL_PRODUCTS } from "../data/products";

type Tab = "hot" | "new" | "sale";

const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
  { key: "hot", label: "Bán chạy", icon: <Flame size={15} /> },
  { key: "new", label: "Hàng mới", icon: <Sparkles size={15} /> },
  { key: "sale", label: "Giảm giá", icon: <TrendingUp size={15} /> },
];

function formatVND(n: number) {
  return n.toLocaleString("vi-VN") + "đ";
}

export function FeaturedProducts() {
  const { addToCart, setCartOpen } = useCart();
  const [activeTab, setActiveTab] = useState<Tab>("hot");
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [addedIds, setAddedIds] = useState<number[]>([]);
  const [previewProduct, setPreviewProduct] = useState<typeof ALL_PRODUCTS[0] | null>(null);

  const filtered = ALL_PRODUCTS.filter(p => (p.tabs ?? []).includes(activeTab));

  const toggleWishlist = (id: number) =>
    setWishlist(w => w.includes(id) ? w.filter(x => x !== id) : [...w, id]);

  const handleAddToCart = (product: typeof ALL_PRODUCTS[0]) => {
    addToCart(product);
    setAddedIds(prev => [...prev, product.id]);
    setTimeout(() => setAddedIds(prev => prev.filter(id => id !== product.id)), 1500);
  };

  const handleBuyNow = (product: typeof ALL_PRODUCTS[0]) => {
    addToCart(product);
    setTimeout(() => setCartOpen(true), 100);
  };

  return (
    <section className="py-12" style={{ background: "#f9f9fb", fontFamily: "var(--font-main)" }}>
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-1 h-6 rounded-full" style={{ background: "var(--main-color)" }}></div>
              <span className="text-sm font-semibold" style={{ color: "var(--main-color)" }}>SẢN PHẨM NỔI BẬT</span>
            </div>
            <h2 className="font-black" style={{ color: "var(--dark)", fontSize: "1.75rem" }}>
              Được Yêu Thích <span style={{ color: "var(--main-color)" }}>Nhất</span>
            </h2>
          </div>
          {/* Tabs */}
          <div className="flex items-center gap-1 bg-white rounded-xl p-1 shadow border" style={{ borderColor: "var(--border-color)" }}>
            {tabs.map(t => (
              <button
                key={t.key}
                onClick={() => setActiveTab(t.key)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all"
                style={activeTab === t.key
                  ? { background: "var(--main-color)", color: "white", boxShadow: "0 2px 8px rgba(227,24,55,0.3)" }
                  : { color: "var(--gray-dark)" }}
              >
                {t.icon}{t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map((p) => {
            const isAdded = addedIds.includes(p.id);
            const isWished = wishlist.includes(p.id);
            return (
              <div key={p.id} className="product-card bg-white rounded-2xl overflow-hidden border group"
                style={{ borderColor: "var(--border-color)", boxShadow: "var(--shadow)" }}>
                {/* Image */}
                <div className="relative overflow-hidden h-48 bg-gray-50">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                  {/* Discount */}
                  {p.discount > 0 && (
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full text-xs font-black text-white"
                      style={{ background: "var(--main-color)" }}>
                      -{p.discount}%
                    </div>
                  )}
                  {/* New badge */}
                  {p.isNew && (
                    <div className="absolute top-2 right-10 px-2 py-0.5 rounded-full text-xs font-bold bg-blue-500 text-white">
                      NEW
                    </div>
                  )}
                  {/* Hover actions */}
                  <div className="product-actions absolute bottom-0 left-0 right-0 flex items-center justify-center gap-2 pb-3">
                    <button
                      onClick={() => toggleWishlist(p.id)}
                      className="w-9 h-9 bg-white rounded-full shadow-lg flex items-center justify-center transition-all hover:scale-110"
                    >
                      <Heart size={15}
                        fill={isWished ? "var(--main-color)" : "none"}
                        style={{ color: "var(--main-color)" }} />
                    </button>
                    <button
                      onClick={() => handleAddToCart(p)}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-full text-white text-xs font-bold shadow-lg transition-all hover:scale-105 active:scale-95"
                      style={{ background: isAdded ? "#16a34a" : "var(--main-color)" }}
                    >
                      {isAdded ? <><Check size={13} /> Đã thêm!</> : <><ShoppingCart size={13} /> Thêm vào giỏ</>}
                    </button>
                    <button
                      onClick={() => setPreviewProduct(p)}
                      className="w-9 h-9 bg-white rounded-full shadow-lg flex items-center justify-center transition-all hover:scale-110"
                    >
                      <Eye size={15} style={{ color: "var(--gray-dark)" }} />
                    </button>
                  </div>
                </div>

                {/* Info */}
                <div className="p-3 space-y-1.5">
                  <div className="text-xs font-semibold" style={{ color: "var(--main-color)" }}>{p.brand}</div>
                  <h3 className="text-sm font-semibold line-clamp-2 leading-snug" style={{ color: "var(--dark)" }}>{p.name}</h3>
                  {/* Rating */}
                  <div className="flex items-center gap-1">
                    {[1,2,3,4,5].map(i => (
                      <Star key={i} size={11}
                        fill={i <= Math.round(p.rating) ? "#f59e0b" : "none"}
                        stroke={i <= Math.round(p.rating) ? "#f59e0b" : "#d1d5db"} />
                    ))}
                    <span className="text-xs" style={{ color: "var(--gray)" }}>({p.reviews})</span>
                    <span className="text-xs ml-auto" style={{ color: "var(--gray)" }}>Đã bán {p.sold.toLocaleString()}</span>
                  </div>
                  {/* Price */}
                  <div className="flex items-baseline gap-2">
                    <span className="font-black" style={{ color: "var(--main-color)", fontSize: "1.05rem" }}>{formatVND(p.price)}</span>
                    {p.oldPrice > p.price && (
                      <span className="text-xs line-through" style={{ color: "var(--gray)" }}>{formatVND(p.oldPrice)}</span>
                    )}
                  </div>
                  {/* Badge + Trả góp */}
                  <div className="flex items-center justify-between">
                    <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "var(--main-color-bg)", color: "var(--main-color)" }}>
                      {p.badge}
                    </span>
                    <span className="text-xs" style={{ color: "var(--gray)" }}>Trả góp 0%</span>
                  </div>
                  {/* Action buttons */}
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => handleAddToCart(p)}
                      className="flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 border"
                      style={isAdded
                        ? { borderColor: "#16a34a", color: "#16a34a", background: "#f0fdf4" }
                        : { borderColor: "var(--main-color)", color: "var(--main-color)", background: "var(--main-color-bg)" }}
                    >
                      {isAdded ? <><Check size={12} /> Đã thêm</> : <><ShoppingCart size={12} /> Thêm giỏ</>}
                    </button>
                    <button
                      onClick={() => handleBuyNow(p)}
                      className="flex-1 py-2 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1 transition-opacity hover:opacity-90 active:scale-95"
                      style={{ background: "var(--main-color)" }}
                    >
                      Mua ngay
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* View more */}
        <div className="flex justify-center mt-8">
          <button
            className="flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-sm transition-all hover:gap-3 border-2"
            style={{ borderColor: "var(--main-color)", color: "var(--main-color)" }}
          >
            Xem thêm sản phẩm <ArrowRight size={16} />
          </button>
        </div>
      </div>

      {/* Product Preview Modal */}
      {previewProduct && (
        <ProductPreviewModal
          product={previewProduct}
          onClose={() => setPreviewProduct(null)}
          onAddToCart={() => { handleAddToCart(previewProduct); setPreviewProduct(null); }}
          onBuyNow={() => { handleBuyNow(previewProduct); setPreviewProduct(null); }}
        />
      )}
    </section>
  );
}

function ProductPreviewModal({ product, onClose, onAddToCart, onBuyNow }: {
  product: typeof ALL_PRODUCTS[0];
  onClose: () => void;
  onAddToCart: () => void;
  onBuyNow: () => void;
}) {
  return (
    <>
      <div className="fixed inset-0 z-[900] bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed inset-0 z-[950] flex items-center justify-center p-4 pointer-events-none">
        <div className="bg-white rounded-2xl shadow-2xl pointer-events-auto w-full max-w-2xl overflow-hidden"
          style={{ fontFamily: "var(--font-main)" }}>
          <div className="flex flex-col sm:flex-row">
            {/* Image */}
            <div className="sm:w-64 h-56 sm:h-auto bg-gray-50 shrink-0 relative overflow-hidden">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
              {product.discount > 0 && (
                <div className="absolute top-3 left-3 px-2 py-1 rounded-full text-sm font-black text-white"
                  style={{ background: "var(--main-color)" }}>
                  -{product.discount}%
                </div>
              )}
            </div>
            {/* Info */}
            <div className="flex-1 p-5 space-y-3">
              {/* Close */}
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-xs font-semibold mb-1" style={{ color: "var(--main-color)" }}>{product.brand} · {product.category}</div>
                  <h3 className="font-black text-lg leading-tight" style={{ color: "var(--dark)" }}>{product.name}</h3>
                </div>
                <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100 transition-colors shrink-0">
                  <ArrowRight size={18} className="rotate-45" style={{ color: "var(--gray)" }} />
                </button>
              </div>
              {/* Stars */}
              <div className="flex items-center gap-2">
                <div className="flex gap-0.5">
                  {[1,2,3,4,5].map(i => (
                    <Star key={i} size={14}
                      fill={i <= Math.round(product.rating) ? "#f59e0b" : "none"}
                      stroke={i <= Math.round(product.rating) ? "#f59e0b" : "#d1d5db"} />
                  ))}
                </div>
                <span className="text-sm" style={{ color: "var(--gray)" }}>{product.rating} ({product.reviews} đánh giá)</span>
              </div>
              {/* Price */}
              <div className="flex items-center gap-3">
                <span className="font-black text-2xl" style={{ color: "var(--main-color)" }}>
                  {product.price.toLocaleString("vi-VN")}đ
                </span>
                {product.oldPrice > product.price && (
                  <span className="text-base line-through" style={{ color: "var(--gray)" }}>
                    {product.oldPrice.toLocaleString("vi-VN")}đ
                  </span>
                )}
              </div>
              {/* Features */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                {["Hàng chính hãng 100%", "Bảo hành 12 tháng", "Đổi trả 30 ngày", "Giao hỏa tốc 2h"].map(f => (
                  <div key={f} className="flex items-center gap-1.5" style={{ color: "var(--gray-dark)" }}>
                    <Check size={12} style={{ color: "#16a34a" }} /> {f}
                  </div>
                ))}
              </div>
              {/* Sold */}
              <div className="text-xs" style={{ color: "var(--gray)" }}>
                Đã bán: <strong style={{ color: "var(--dark)" }}>{product.sold.toLocaleString()}</strong> sản phẩm
              </div>
              {/* Buttons */}
              <div className="flex gap-2.5 pt-1">
                <button onClick={onAddToCart}
                  className="flex-1 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 border-2"
                  style={{ borderColor: "var(--main-color)", color: "var(--main-color)", background: "var(--main-color-bg)" }}>
                  <ShoppingCart size={16} /> Thêm vào giỏ
                </button>
                <button onClick={onBuyNow}
                  className="flex-1 py-3 rounded-xl font-bold text-sm text-white flex items-center justify-center gap-2 transition-opacity hover:opacity-90 active:scale-95"
                  style={{ background: "var(--main-color)" }}>
                  Mua ngay →
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
