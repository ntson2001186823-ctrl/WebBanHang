import { ArrowRight, Zap } from "lucide-react";

const promoCards = [
  {
    id: 1,
    tag: "📱 Hot deal",
    title: "iPhone 16 Series",
    desc: "Ưu đãi lên đến 5 triệu đồng khi thu cũ đổi mới",
    cta: "Xem ngay",
    image: "https://images.unsplash.com/photo-1760900051041-90417b9c110e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    bg: "linear-gradient(135deg, #1a0a0d 0%, #4a0e1a 100%)",
    accent: "#ff4d6d",
  },
  {
    id: 2,
    tag: "⌚ Mới về",
    title: "Apple Watch Ultra 3",
    desc: "Đồng hồ thông minh cao cấp nhất từ Apple - Titan Series",
    cta: "Mua ngay",
    image: "https://images.unsplash.com/photo-1758348844355-2ef28345979d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    bg: "linear-gradient(135deg, #0a1630 0%, #1a2d5a 100%)",
    accent: "#60a5fa",
  },
];

const brandLogos = [
  { name: "Apple", icon: "🍎", desc: "Chính hãng VNA" },
  { name: "Samsung", icon: "📱", desc: "Galaxy Series" },
  { name: "Sony", icon: "🎵", desc: "Audio & Camera" },
  { name: "Dell", icon: "💻", desc: "XPS & Alienware" },
  { name: "ASUS", icon: "🖥️", desc: "ROG Gaming" },
  { name: "Canon", icon: "📷", desc: "EOS Series" },
  { name: "LG", icon: "📺", desc: "OLED TV" },
  { name: "Xiaomi", icon: "⚡", desc: "Flagship Series" },
];

export function PromoSection() {
  return (
    <section className="py-10" style={{ background: "white", fontFamily: "var(--font-main)" }}>
      <div className="max-w-7xl mx-auto px-4 space-y-10">
        {/* Promo Banner Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {promoCards.map(card => (
            <div key={card.id} className="relative rounded-2xl overflow-hidden group cursor-pointer h-48"
              style={{ background: card.bg, boxShadow: "var(--shadow)" }}>
              {/* Background Image with overlay */}
              <img
                src={card.image}
                alt={card.title}
                className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:opacity-40 transition-opacity duration-500 group-hover:scale-110 transition-transform"
                style={{ transition: "all 0.5s ease" }}
              />
              <div className="relative z-10 p-6 h-full flex flex-col justify-between text-white">
                <div className="space-y-2">
                  <span className="text-xs font-bold px-2 py-1 rounded-full bg-white/20 backdrop-blur">
                    {card.tag}
                  </span>
                  <h3 className="text-2xl font-black">{card.title}</h3>
                  <p className="text-sm text-white/80 max-w-xs">{card.desc}</p>
                </div>
                <button
                  className="self-start flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all hover:gap-3"
                  style={{ background: card.accent, color: "white" }}
                >
                  {card.cta} <ArrowRight size={14} />
                </button>
              </div>
              {/* Glow */}
              <div className="absolute -bottom-4 -right-4 w-32 h-32 rounded-full opacity-20 blur-2xl"
                style={{ background: card.accent }} />
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4">
          <div className="flex-1 h-px bg-gray-100"></div>
          <div className="flex items-center gap-2 px-4 py-1.5 rounded-full border text-xs font-semibold"
            style={{ borderColor: "var(--main-color)", color: "var(--main-color)" }}>
            <Zap size={12} /> THƯƠNG HIỆU ĐỐI TÁC
          </div>
          <div className="flex-1 h-px bg-gray-100"></div>
        </div>

        {/* Brands */}
        <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
          {brandLogos.map((b) => (
            <a key={b.name} href="#" className="group flex flex-col items-center gap-2 p-3 rounded-2xl bg-white border transition-all hover:-translate-y-1"
              style={{ borderColor: "var(--border-color)", boxShadow: "var(--shadow)" }}>
              <div className="text-3xl group-hover:scale-110 transition-transform">{b.icon}</div>
              <div className="text-center">
                <div className="text-xs font-bold" style={{ color: "var(--dark)" }}>{b.name}</div>
                <div className="text-xs" style={{ color: "var(--gray)" }}>{b.desc}</div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
