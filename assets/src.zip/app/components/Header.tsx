import { useState, useEffect } from "react";
import {
  Search, ShoppingCart, Heart, User, Phone, Mail, ChevronDown,
  Menu, X, MapPin, Bell, Truck, Shield, RotateCcw, Headphones
} from "lucide-react";
import { useCart } from "../context/CartContext";

const navCategories = [
  {
    label: "Điện thoại",
    icon: "📱",
    sub: ["iPhone", "Samsung Galaxy", "Xiaomi", "OPPO", "Vivo", "Realme"],
  },
  {
    label: "Laptop",
    icon: "💻",
    sub: ["MacBook", "Dell", "HP", "Lenovo", "ASUS", "Acer"],
  },
  {
    label: "Máy tính bảng",
    icon: "📟",
    sub: ["iPad", "Samsung Tab", "Xiaomi Pad"],
  },
  {
    label: "Tai nghe",
    icon: "🎧",
    sub: ["True Wireless", "Chụp tai", "Gaming", "Studio"],
  },
  {
    label: "TV & Màn hình",
    icon: "📺",
    sub: ["Smart TV 4K", "OLED TV", "Màn hình gaming", "Máy chiếu"],
  },
  {
    label: "Máy ảnh",
    icon: "📷",
    sub: ["DSLR", "Mirrorless", "Compact", "Action Cam"],
  },
  {
    label: "Gaming",
    icon: "🎮",
    sub: ["Console", "Tay cầm", "Tai nghe Gaming", "Ghế Gaming"],
  },
];

const POPULAR_QUICK = ["iPhone 16 Pro", "MacBook Air", "Samsung S25", "AirPods Pro", "PS5"];

export function Header() {
  const { totalItems, setCartOpen, setSearchOpen } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [wishCount] = useState(5);
  const [sticky, setSticky] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<number | null>(null);
  const [searchFocused, setSearchFocused] = useState(false);

  useEffect(() => {
    const handleScroll = () => setSticky(window.scrollY > 80);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const openSearch = () => setSearchOpen(true);

  return (
    <header style={{ fontFamily: "var(--font-main)" }}>
      {/* TOP BAR */}
      <div style={{ background: "var(--main-color)" }} className="text-white text-sm py-2">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between gap-4">
          {/* Ticker */}
          <div className="hidden md:flex items-center gap-2 overflow-hidden flex-1">
            <Bell size={14} className="shrink-0 animate-pulse" />
            <div className="overflow-hidden relative w-full">
              <span className="ticker-text inline-block whitespace-nowrap text-xs">
                🔥 Siêu sale tháng 3 — Giảm đến 50% toàn bộ sản phẩm! &nbsp;&nbsp;&nbsp;
                📦 Miễn phí vận chuyển cho đơn hàng từ 500K &nbsp;&nbsp;&nbsp;
                🎁 Tặng tai nghe trị giá 500K khi mua laptop &nbsp;&nbsp;&nbsp;
                ⚡ Flash Sale 12:00 hôm nay — Đừng bỏ lỡ!
              </span>
            </div>
          </div>
          {/* Contact */}
          <div className="flex items-center gap-4 shrink-0 text-xs">
            <a href="tel:19001234" className="flex items-center gap-1 hover:text-yellow-200 transition-colors">
              <Phone size={12} /><span>1900 1234</span>
            </a>
            <a href="mailto:support@techshop.vn" className="hidden lg:flex items-center gap-1 hover:text-yellow-200 transition-colors">
              <Mail size={12} /><span>support@techshop.vn</span>
            </a>
            <a href="#" className="hidden sm:flex items-center gap-1 hover:text-yellow-200 transition-colors">
              <MapPin size={12} /><span>Hệ thống cửa hàng</span>
            </a>
          </div>
        </div>
      </div>

      {/* MAIN HEADER */}
      <div
        className={`bg-white transition-all duration-300 ${sticky ? "shadow-lg py-2" : "py-4"}`}
        style={{ position: "sticky", top: 0, zIndex: 1000, borderBottom: "1px solid var(--border-color)" }}
      >
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-4">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2 shrink-0">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-xl font-black shadow-lg"
              style={{ background: "var(--main-color)" }}
            >
              T
            </div>
            <div className="hidden sm:block leading-tight">
              <div className="text-lg font-black" style={{ color: "var(--main-color)", fontFamily: "var(--font-main)" }}>
                TECH<span style={{ color: "var(--dark)" }}>SHOP</span>
              </div>
              <div className="text-xs" style={{ color: "var(--gray)" }}>Điện tử chính hãng</div>
            </div>
          </a>

          {/* Search Bar — click to open overlay */}
          <div className="flex-1 relative">
            <div
              className="flex overflow-hidden rounded-xl border-2 cursor-pointer transition-all"
              style={{ borderColor: searchFocused ? "var(--main-color)" : "var(--main-color)" }}
              onClick={openSearch}
            >
              <div className="flex-1 px-4 py-2.5 text-sm bg-gray-50 flex items-center gap-2">
                <Search size={15} style={{ color: "var(--gray)" }} />
                <span style={{ color: "var(--gray)" }}>Tìm kiếm điện thoại, laptop, tai nghe...</span>
              </div>
              <button
                className="px-5 py-2.5 text-white font-semibold text-sm transition-colors hover:opacity-90"
                style={{ background: "var(--main-color)" }}
                onClick={openSearch}
              >
                <Search size={18} />
              </button>
            </div>
            {/* Quick suggestions shown on hover */}
            <div className="hidden md:flex items-center gap-1.5 mt-1.5 px-1">
              <span className="text-xs" style={{ color: "var(--gray)" }}>Gợi ý:</span>
              {POPULAR_QUICK.map(s => (
                <button
                  key={s}
                  onClick={openSearch}
                  className="text-xs hover:underline transition-colors"
                  style={{ color: "var(--main-color)" }}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Wishlist */}
            <a href="#" className="relative p-2.5 rounded-xl hover:bg-red-50 transition-colors hidden sm:flex">
              <Heart size={22} style={{ color: "var(--main-color)" }} />
              <span
                className="badge-bounce absolute -top-1 -right-1 w-5 h-5 rounded-full text-white text-xs flex items-center justify-center font-bold"
                style={{ background: "var(--main-color)" }}
              >
                {wishCount}
              </span>
            </a>

            {/* Cart Button */}
            <button
              onClick={() => setCartOpen(true)}
              className="relative flex items-center gap-2 px-3 py-2.5 rounded-xl text-white transition-all hover:opacity-90 active:scale-95"
              style={{ background: "var(--main-color)" }}
            >
              <ShoppingCart size={20} />
              <span className="hidden sm:block text-sm font-semibold">Giỏ hàng</span>
              {totalItems > 0 && (
                <span
                  className="badge-bounce absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-yellow-400 text-gray-900 text-xs flex items-center justify-center font-bold"
                >
                  {totalItems}
                </span>
              )}
            </button>

            {/* User */}
            <a href="#" className="p-2.5 rounded-xl hover:bg-gray-100 transition-colors hidden md:flex">
              <User size={22} style={{ color: "var(--dark)" }} />
            </a>

            {/* Mobile menu */}
            <button
              className="p-2.5 rounded-xl hover:bg-gray-100 transition-colors lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </div>

      {/* NAV BAR */}
      <div className="bg-white hidden lg:block border-b" style={{ borderColor: "var(--border-color)" }}>
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-1">
          {navCategories.map((cat, i) => (
            <div
              key={cat.label}
              className="relative group"
              onMouseEnter={() => setActiveDropdown(i)}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="flex items-center gap-1.5 px-3 py-3 text-sm font-medium nav-link transition-colors hover:text-red-600 whitespace-nowrap"
                style={{ color: "var(--dark)" }}>
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
                <ChevronDown size={13} className="transition-transform group-hover:rotate-180" />
              </button>
              {/* Dropdown */}
              {activeDropdown === i && (
                <div className="absolute top-full left-0 bg-white rounded-xl shadow-2xl p-3 min-w-[200px] z-50 border"
                  style={{ borderColor: "var(--border-color)" }}>
                  {cat.sub.map(s => (
                    <a key={s} href="#" className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm hover:bg-red-50 hover:text-red-600 transition-colors"
                      style={{ color: "var(--gray-dark)" }}>
                      <span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--main-color)" }}></span>
                      {s}
                    </a>
                  ))}
                </div>
              )}
            </div>
          ))}
          <div className="ml-auto flex items-center gap-4 text-xs pl-4" style={{ color: "var(--gray)" }}>
            <span className="flex items-center gap-1">
              <Truck size={14} style={{ color: "var(--main-color)" }} /> Ship hỏa tốc
            </span>
            <span className="flex items-center gap-1">
              <Shield size={14} style={{ color: "var(--main-color)" }} /> BH 12 tháng
            </span>
            <span className="flex items-center gap-1">
              <RotateCcw size={14} style={{ color: "var(--main-color)" }} /> Đổi 30 ngày
            </span>
            <span className="flex items-center gap-1">
              <Headphones size={14} style={{ color: "var(--main-color)" }} /> Hỗ trợ 24/7
            </span>
          </div>
        </div>
      </div>

      {/* MOBILE MENU */}
      {mobileOpen && (
        <div className="lg:hidden bg-white border-t shadow-xl" style={{ borderColor: "var(--border-color)" }}>
          {/* Mobile search */}
          <div className="px-4 py-3 border-b" style={{ borderColor: "var(--border-color)" }}>
            <button
              onClick={openSearch}
              className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm bg-gray-100 text-left"
              style={{ color: "var(--gray)" }}
            >
              <Search size={16} /> Tìm kiếm sản phẩm...
            </button>
          </div>
          <div className="max-w-7xl mx-auto px-4 py-3 space-y-1">
            {navCategories.map(cat => (
              <a key={cat.label} href="#" className="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-red-50 transition-colors"
                style={{ color: "var(--dark)" }}>
                <span className="text-lg">{cat.icon}</span>
                <span className="font-medium text-sm">{cat.label}</span>
                <ChevronDown size={14} className="ml-auto" style={{ color: "var(--gray)" }} />
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
