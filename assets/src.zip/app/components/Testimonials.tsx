import { Star, Quote } from "lucide-react";

const reviews = [
  {
    id: 1,
    name: "Nguyễn Minh Tuấn",
    avatar: "NMT",
    color: "#e31837",
    product: "iPhone 16 Pro Max",
    rating: 5,
    time: "2 ngày trước",
    text: "Sản phẩm chính hãng 100%, giao hàng siêu nhanh chỉ 2 tiếng. Nhân viên tư vấn rất nhiệt tình và chuyên nghiệp. Sẽ tiếp tục ủng hộ TechShop!",
  },
  {
    id: 2,
    name: "Trần Thị Bảo Châu",
    avatar: "TBC",
    color: "#7c3aed",
    product: "MacBook Air M3",
    rating: 5,
    time: "5 ngày trước",
    text: "Mua MacBook tại đây giá tốt hơn nhiều nơi khác mà lại có quà tặng phụ kiện nữa. Máy được kích hoạt bảo hành chính hãng Apple luôn. Cực kỳ uy tín!",
  },
  {
    id: 3,
    name: "Phạm Quốc Hùng",
    avatar: "PQH",
    color: "#2563eb",
    product: "Sony WH-1000XM6",
    rating: 5,
    time: "1 tuần trước",
    text: "Chất lượng âm thanh đỉnh cao, chống ồn cực tốt. TechShop có chính sách đổi trả 30 ngày rất yên tâm. Nhân viên hỗ trợ 24/7 rất chu đáo.",
  },
];

const stats = [
  { value: "2M+", label: "Khách hàng hài lòng" },
  { value: "200+", label: "Cửa hàng toàn quốc" },
  { value: "50K+", label: "Sản phẩm chính hãng" },
  { value: "4.9★", label: "Điểm đánh giá trung bình" },
];

export function Testimonials() {
  return (
    <section className="py-12" style={{ background: "var(--gray-light)", fontFamily: "var(--font-main)" }}>
      <div className="max-w-7xl mx-auto px-4">
        {/* Stats */}
        <div
          className="rounded-2xl p-6 mb-10 grid grid-cols-2 md:grid-cols-4 gap-6"
          style={{ background: "linear-gradient(135deg, var(--main-color-dark), var(--main-color))" }}
        >
          {stats.map((s, i) => (
            <div key={i} className="text-center text-white">
              <div className="font-black text-3xl">{s.value}</div>
              <div className="text-sm text-white/80 mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-2">
            <div className="w-6 h-0.5 rounded" style={{ background: "var(--main-color)" }}></div>
            <span className="text-sm font-semibold" style={{ color: "var(--main-color)" }}>NHẬN XÉT KHÁCH HÀNG</span>
            <div className="w-6 h-0.5 rounded" style={{ background: "var(--main-color)" }}></div>
          </div>
          <h2 className="font-black" style={{ color: "var(--dark)", fontSize: "1.75rem" }}>
            Khách Hàng Nói Gì Về <span style={{ color: "var(--main-color)" }}>TechShop?</span>
          </h2>
        </div>

        {/* Review Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {reviews.map(r => (
            <div key={r.id} className="bg-white rounded-2xl p-5 relative" style={{ boxShadow: "var(--shadow)", border: "1px solid var(--border-color)" }}>
              {/* Quote icon */}
              <div className="absolute top-4 right-4 opacity-10">
                <Quote size={40} style={{ color: r.color }} />
              </div>
              {/* Stars */}
              <div className="flex items-center gap-0.5 mb-3">
                {[1, 2, 3, 4, 5].map(i => (
                  <Star key={i} size={14} fill={i <= r.rating ? "#f59e0b" : "none"} stroke={i <= r.rating ? "#f59e0b" : "#d1d5db"} />
                ))}
                <span className="text-xs ml-2" style={{ color: "var(--gray)" }}>{r.time}</span>
              </div>
              {/* Text */}
              <p className="text-sm leading-relaxed mb-4" style={{ color: "var(--gray-dark)" }}>"{r.text}"</p>
              {/* Product */}
              <div className="text-xs px-2 py-1 rounded-lg inline-block mb-4" style={{ background: "var(--gray-light)", color: "var(--gray)" }}>
                Đã mua: {r.product}
              </div>
              {/* User */}
              <div className="flex items-center gap-3 border-t pt-3" style={{ borderColor: "var(--border-color)" }}>
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                  style={{ background: r.color }}
                >
                  {r.avatar}
                </div>
                <div>
                  <div className="text-sm font-bold" style={{ color: "var(--dark)" }}>{r.name}</div>
                  <div className="text-xs" style={{ color: "var(--gray)" }}>Khách hàng thân thiết ⭐</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
