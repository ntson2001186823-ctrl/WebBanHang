import { useState, useEffect } from "react";
import { Zap, ShoppingCart, Heart, ArrowRight, Star, Check } from "lucide-react";
import { useCart } from "../context/CartContext";
import { ALL_PRODUCTS } from "../data/products";

const flashProducts = ALL_PRODUCTS.filter(p => p.flashSale);

function useCountdown(endTime: Date) {
  const getRemaining = () => {
    const diff = Math.max(0, endTime.getTime() - Date.now());
    return {
      h: Math.floor(diff / 3600000),
      m: Math.floor((diff % 3600000) / 60000),
      s: Math.floor((diff % 60000) / 1000),
    };
  };
  const [time, setTime] = useState(getRemaining);
  useEffect(() => {
    const t = setInterval(() => setTime(getRemaining()), 1000);
    return () => clearInterval(t);
  }, []);
  return time;
}

function formatVND(n: number) {
  return n.toLocaleString("vi-VN") + "đ";
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star key={i} size={11}
          fill={i <= Math.round(rating) ? "#f59e0b" : "none"}
          stroke={i <= Math.round(rating) ? "#f59e0b" : "#d1d5db"} />
      ))}
    </div>
  );
}

export function FlashSale() {
  const { addToCart } = useCart();
  const endTime = new Date(Date.now() + 5 * 3600000 + 23 * 60000 + 45000);
  const { h, m, s } = useCountdown(endTime);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [addedIds, setAddedIds] = useState<number[]>([]);

  const pad = (n: number) => String(n).padStart(2, "0");

  const handleAddToCart = (product: typeof flashProducts[0]) => {
    addToCart(product);
    setAddedIds(prev => [...prev, product.id]);
    setTimeout(() => setAddedIds(prev => prev.filter(id => id !== product.id)), 1500);
  };

  const toggleWish = (id: number) =>
    setWishlist(w => w.includes(id) ? w.filter(x => x !== id) : [...w, id]);

  return (
    <section className="py-10" style={{ background: "#fff", fontFamily: "var(--font-main)" }}>
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div
          className="flex items-center justify-between mb-6 rounded-2xl px-5 py-4"
          style={{ background: "linear-gradient(135deg, var(--main-color-dark), var(--main-color))" }}
        >
          <div className="flex items-center gap-3 text-white flex-wrap">
            <div className="bg-white/20 p-2 rounded-xl">
              <Zap size={20} fill="white" />
            </div>
            <div>
              <div className="font-black text-xl tracking-wide">⚡ FLASH SALE</div>
              <div className="text-xs text-white/80">Kết thúc trong:</div>
            </div>
            {/* Countdown */}
            <div className="flex items-center gap-1.5 ml-2">
              {[pad(h), pad(m), pad(s)].map((t, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  <div
                    className="bg-white rounded-lg w-10 h-10 flex items-center justify-center font-black text-lg tabular-nums"
                    style={{ color: "var(--main-color)", boxShadow: "0 2px 8px rgba(0,0,0,0.2)" }}
                  >
                    {t}
                  </div>
                  {i < 2 && <span className="text-white font-black text-lg">:</span>}
                </div>
              ))}
            </div>
          </div>
          <a href="#" className="hidden sm:flex items-center gap-1.5 bg-white/20 hover:bg-white/30 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-all">
            Xem tất cả <ArrowRight size={15} />
          </a>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {flashProducts.map((p) => {
            const pct = Math.round(((p.flashSold ?? 0) / (p.flashTotal ?? 1)) * 100);
            const isAdded = addedIds.includes(p.id);
            return (
              <div key={p.id} className="product-card bg-white rounded-2xl overflow-hidden border"
                style={{ borderColor: "var(--border-color)", boxShadow: "var(--shadow)" }}>
                {/* Image */}
                <div className="relative overflow-hidden h-44 bg-gray-50">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  {/* Discount */}
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full text-xs font-black text-white"
                    style={{ background: "var(--main-color)" }}>
                    -{p.discount}%
                  </div>
                  {/* Wishlist */}
                  <button
                    onClick={() => toggleWish(p.id)}
                    className="absolute top-2 right-2 w-8 h-8 bg-white rounded-full shadow flex items-center justify-center hover:bg-red-50 transition-colors">
                    <Heart size={14}
                      fill={wishlist.includes(p.id) ? "var(--main-color)" : "none"}
                      style={{ color: "var(--main-color)" }} />
                  </button>
                  {/* Quick add */}
                  <button
                    onClick={() => handleAddToCart(p)}
                    className="product-actions absolute bottom-2 left-1/2 -translate-x-1/2 w-max px-3 py-1.5 rounded-full text-white text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95"
                    style={{ background: isAdded ? "#16a34a" : "var(--main-color)" }}
                  >
                    {isAdded ? <><Check size={12} /> Đã thêm!</> : <><ShoppingCart size={12} /> Thêm vào giỏ</>}
                  </button>
                </div>

                {/* Info */}
                <div className="p-3 space-y-2">
                  <h3 className="text-sm font-semibold line-clamp-2 leading-tight" style={{ color: "var(--dark)" }}>{p.name}</h3>
                  <div className="flex items-center gap-1.5">
                    <StarRating rating={p.rating} />
                    <span className="text-xs" style={{ color: "var(--gray)" }}>({p.reviews})</span>
                  </div>
                  <div>
                    <div className="font-black" style={{ color: "var(--main-color)", fontSize: "1rem" }}>
                      {formatVND(p.price)}
                    </div>
                    <div className="text-xs line-through" style={{ color: "var(--gray)" }}>{formatVND(p.oldPrice)}</div>
                  </div>
                  {/* Progress */}
                  <div>
                    <div className="flex justify-between text-xs mb-1" style={{ color: "var(--gray)" }}>
                      <span>Đã bán: {p.flashSold}/{p.flashTotal}</span>
                      <span>{pct}%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="progress-bar-fill h-full rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                    {pct >= 70 && (
                      <div className="text-xs mt-0.5 font-semibold" style={{ color: "var(--main-color)" }}>
                        🔥 Sắp hết hàng!
                      </div>
                    )}
                  </div>
                  {/* Add to cart button */}
                  <button
                    onClick={() => handleAddToCart(p)}
                    className="w-full py-2 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all active:scale-95"
                    style={isAdded
                      ? { background: "#f0fdf4", color: "#16a34a", border: "1px solid #16a34a" }
                      : { background: "var(--main-color-bg)", color: "var(--main-color)", border: "1px solid var(--main-color)" }}>
                    {isAdded ? <><Check size={14} /> Đã thêm vào giỏ!</> : <><ShoppingCart size={14} /> Thêm vào giỏ hàng</>}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
