import { useEffect } from "react";
import { X, ShoppingCart, Trash2, Plus, Minus, Tag, Truck, ArrowRight, ShoppingBag } from "lucide-react";
import { useCart } from "../context/CartContext";

function formatVND(n: number) {
  return n.toLocaleString("vi-VN") + "đ";
}

export function CartDrawer() {
  const { items, cartOpen, setCartOpen, removeFromCart, updateQty, clearCart, totalItems, totalPrice } = useCart();

  // lock body scroll when open
  useEffect(() => {
    document.body.style.overflow = cartOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [cartOpen]);

  // ESC to close
  useEffect(() => {
    const fn = (e: KeyboardEvent) => e.key === "Escape" && setCartOpen(false);
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [setCartOpen]);

  const shipping = totalPrice >= 500000 ? 0 : 30000;
  const discount = totalItems >= 2 ? Math.round(totalPrice * 0.05) : 0;
  const finalTotal = totalPrice + shipping - discount;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-[1100] transition-opacity duration-300"
        style={{
          background: "rgba(0,0,0,0.5)",
          opacity: cartOpen ? 1 : 0,
          pointerEvents: cartOpen ? "auto" : "none",
          backdropFilter: "blur(2px)",
        }}
        onClick={() => setCartOpen(false)}
      />

      {/* Drawer */}
      <div
        className="fixed top-0 right-0 h-full z-[1200] bg-white flex flex-col transition-transform duration-300 ease-in-out"
        style={{
          width: "min(420px, 100vw)",
          transform: cartOpen ? "translateX(0)" : "translateX(100%)",
          boxShadow: "-8px 0 40px rgba(0,0,0,0.15)",
          fontFamily: "var(--font-main)",
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: "var(--border-color)" }}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "var(--main-color-bg)" }}>
              <ShoppingCart size={18} style={{ color: "var(--main-color)" }} />
            </div>
            <div>
              <div className="font-black" style={{ color: "var(--dark)" }}>Giỏ hàng của bạn</div>
              <div className="text-xs" style={{ color: "var(--gray)" }}>{totalItems} sản phẩm</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {items.length > 0 && (
              <button
                onClick={clearCart}
                className="text-xs px-3 py-1.5 rounded-lg border transition-colors hover:bg-red-50"
                style={{ borderColor: "var(--border-color)", color: "var(--gray)" }}
              >
                Xóa tất cả
              </button>
            )}
            <button
              onClick={() => setCartOpen(false)}
              className="w-9 h-9 rounded-xl hover:bg-gray-100 flex items-center justify-center transition-colors"
            >
              <X size={18} style={{ color: "var(--dark)" }} />
            </button>
          </div>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 py-16">
              <div className="w-24 h-24 rounded-full flex items-center justify-center" style={{ background: "var(--gray-light)" }}>
                <ShoppingBag size={40} style={{ color: "var(--gray)" }} />
              </div>
              <div className="text-center">
                <div className="font-bold text-lg" style={{ color: "var(--dark)" }}>Giỏ hàng trống</div>
                <div className="text-sm mt-1" style={{ color: "var(--gray)" }}>Hãy thêm sản phẩm yêu thích vào giỏ!</div>
              </div>
              <button
                onClick={() => setCartOpen(false)}
                className="px-6 py-2.5 rounded-xl text-white font-semibold text-sm transition-opacity hover:opacity-90"
                style={{ background: "var(--main-color)" }}
              >
                Tiếp tục mua sắm
              </button>
            </div>
          ) : (
            <div className="p-4 space-y-3">
              {/* Free shipping notice */}
              {shipping > 0 && (
                <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm" style={{ background: "#fff8e1" }}>
                  <Truck size={15} className="shrink-0" style={{ color: "#f59e0b" }} />
                  <span style={{ color: "#92400e" }}>
                    Mua thêm <strong>{formatVND(500000 - totalPrice)}</strong> để được miễn phí vận chuyển!
                  </span>
                </div>
              )}
              {shipping === 0 && (
                <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm" style={{ background: "#f0fdf4" }}>
                  <Truck size={15} className="shrink-0" style={{ color: "#16a34a" }} />
                  <span style={{ color: "#15803d" }}>🎉 Bạn được <strong>miễn phí vận chuyển!</strong></span>
                </div>
              )}

              {items.map((item) => (
                <div key={item.id} className="flex gap-3 p-3 rounded-2xl border" style={{ borderColor: "var(--border-color)" }}>
                  {/* Image */}
                  <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-gray-50">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  {/* Info */}
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="text-xs font-semibold" style={{ color: "var(--main-color)" }}>{item.brand}</div>
                    <h4 className="text-sm font-semibold line-clamp-2 leading-snug" style={{ color: "var(--dark)" }}>{item.name}</h4>
                    <div className="flex items-center justify-between">
                      <span className="font-black text-sm" style={{ color: "var(--main-color)" }}>{formatVND(item.price)}</span>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors hover:bg-red-50"
                      >
                        <Trash2 size={14} style={{ color: "var(--main-color)" }} />
                      </button>
                    </div>
                    {/* Qty controls */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateQty(item.id, item.qty - 1)}
                        className="w-7 h-7 rounded-lg border flex items-center justify-center transition-all hover:border-red-400"
                        style={{ borderColor: "var(--border-color)" }}
                      >
                        <Minus size={12} />
                      </button>
                      <span className="w-8 text-center text-sm font-bold tabular-nums">{item.qty}</span>
                      <button
                        onClick={() => updateQty(item.id, item.qty + 1)}
                        className="w-7 h-7 rounded-lg border flex items-center justify-center transition-all hover:border-red-400 hover:bg-red-50"
                        style={{ borderColor: "var(--border-color)" }}
                      >
                        <Plus size={12} />
                      </button>
                      <span className="text-xs ml-auto" style={{ color: "var(--gray)" }}>
                        = {formatVND(item.price * item.qty)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer summary */}
        {items.length > 0 && (
          <div className="border-t p-4 space-y-3" style={{ borderColor: "var(--border-color)", background: "#fafafa" }}>
            {/* Promo code */}
            <div className="flex gap-2">
              <div className="flex items-center gap-2 flex-1 px-3 py-2 rounded-xl border bg-white" style={{ borderColor: "var(--border-color)" }}>
                <Tag size={14} style={{ color: "var(--gray)" }} />
                <input
                  type="text"
                  placeholder="Nhập mã giảm giá..."
                  className="flex-1 text-sm outline-none bg-transparent"
                  style={{ fontFamily: "var(--font-main)" }}
                />
              </div>
              <button className="px-4 py-2 rounded-xl text-white text-sm font-bold transition-opacity hover:opacity-90"
                style={{ background: "var(--main-color)" }}>
                Áp dụng
              </button>
            </div>

            {/* Price breakdown */}
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between" style={{ color: "var(--gray-dark)" }}>
                <span>Tạm tính ({totalItems} sp)</span>
                <span>{formatVND(totalPrice)}</span>
              </div>
              <div className="flex justify-between" style={{ color: "var(--gray-dark)" }}>
                <span>Vận chuyển</span>
                <span style={{ color: shipping === 0 ? "#16a34a" : "var(--dark)" }}>
                  {shipping === 0 ? "Miễn phí" : formatVND(shipping)}
                </span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between" style={{ color: "#16a34a" }}>
                  <span>Giảm giá mua nhiều (5%)</span>
                  <span>-{formatVND(discount)}</span>
                </div>
              )}
              <div className="flex justify-between font-black pt-2 border-t text-base" style={{ borderColor: "var(--border-color)", color: "var(--dark)" }}>
                <span>Tổng cộng</span>
                <span style={{ color: "var(--main-color)" }}>{formatVND(finalTotal)}</span>
              </div>
            </div>

            {/* Checkout button */}
            <button
              className="w-full py-3.5 rounded-xl text-white font-black text-sm flex items-center justify-center gap-2 transition-opacity hover:opacity-90 shadow-lg"
              style={{ background: "linear-gradient(135deg, var(--main-color-dark), var(--main-color))" }}
            >
              Tiến hành thanh toán <ArrowRight size={16} />
            </button>
            <button
              onClick={() => setCartOpen(false)}
              className="w-full py-2.5 rounded-xl text-sm font-semibold border-2 transition-all hover:bg-red-50"
              style={{ borderColor: "var(--main-color)", color: "var(--main-color)" }}
            >
              Tiếp tục mua sắm
            </button>
          </div>
        )}
      </div>
    </>
  );
}
