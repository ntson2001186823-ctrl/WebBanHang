import { useState, useEffect, useCallback } from "react";
import { ChevronLeft, ChevronRight, Zap, Gift, Star } from "lucide-react";

const slides = [
  {
    id: 1,
    badge: "🔥 SIÊU SALE THÁNG 3",
    title: "iPhone 16 Pro Max",
    subtitle: "Titan. Mạnh mẽ. Đột phá.",
    desc: "Camera 48MP thế hệ mới · Chip A18 Pro · Pin cả ngày",
    price: "29.990.000đ",
    oldPrice: "35.990.000đ",
    discount: "17%",
    cta: "Mua ngay",
    ctaSecond: "Trả góp 0%",
    image: "https://images.unsplash.com/photo-1760900051041-90417b9c110e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    bg: "linear-gradient(135deg, #1a0a0d 0%, #3d0b12 40%, #6b1120 100%)",
    accent: "#ff4d6d",
    tag: "HOT",
  },
  {
    id: 2,
    badge: "⚡ FLASH DEAL",
    title: "Gaming Setup",
    subtitle: "Chinh phục mọi trận chiến",
    desc: "Màn hình 240Hz · RTX 4080 · Đèn RGB · Tản nhiệt siêu khủng",
    price: "45.990.000đ",
    oldPrice: "58.000.000đ",
    discount: "21%",
    cta: "Khám phá",
    ctaSecond: "Xem tất cả",
    image: "https://images.unsplash.com/photo-1614179924047-e1ab49a0a0cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    bg: "linear-gradient(135deg, #0a0a1a 0%, #1a0a3d 40%, #2d0a6b 100%)",
    accent: "#7c3aed",
    tag: "NEW",
  },
  {
    id: 3,
    badge: "💻 BEST SELLER",
    title: "MacBook Air M3",
    subtitle: "Mỏng nhẹ. Hiệu năng thần thánh.",
    desc: "Chip M3 · 18 giờ pin · Màn hình Liquid Retina · 256GB SSD",
    price: "27.990.000đ",
    oldPrice: "32.990.000đ",
    discount: "15%",
    cta: "Mua ngay",
    ctaSecond: "So sánh",
    image: "https://images.unsplash.com/photo-1668095736209-cb9debc6fada?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    bg: "linear-gradient(135deg, #0a1a0d 0%, #0a3d1a 40%, #0a6b2d 100%)",
    accent: "#16a34a",
    tag: "SALE",
  },
];

export function BannerSlider() {
  const [current, setCurrent] = useState(0);
  const [animKey, setAnimKey] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const goTo = useCallback((index: number) => {
    setCurrent(index);
    setAnimKey(k => k + 1);
  }, []);

  const prev = () => goTo((current - 1 + slides.length) % slides.length);
  const next = useCallback(() => goTo((current + 1) % slides.length), [current, goTo]);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, [next, isPaused]);

  const slide = slides[current];

  return (
    <section className="relative overflow-hidden" style={{ background: slide.bg, minHeight: 460, transition: "background 0.8s ease" }}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}>
      
      {/* Decorative circles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full opacity-10"
          style={{ background: slide.accent, filter: "blur(60px)" }} />
        <div className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full opacity-10"
          style={{ background: slide.accent, filter: "blur(80px)" }} />
        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-5"
          style={{ backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)", backgroundSize: "40px 40px" }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 lg:py-12 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-16">
          {/* Content */}
          <div key={`content-${animKey}`} className="flex-1 space-y-4 animate-slide-left text-white text-center lg:text-left">
            {/* Badge */}
            <div className="inline-flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold text-white"
                style={{ background: "var(--main-color)" }}>
                {slide.badge}
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-yellow-400 text-gray-900">
                -{slide.discount}
              </span>
            </div>
            {/* Title */}
            <h1 className="text-4xl lg:text-5xl font-black text-white leading-tight">
              {slide.title}
            </h1>
            <p className="text-lg font-semibold" style={{ color: slide.accent }}>{slide.subtitle}</p>
            <p className="text-sm text-white/70 max-w-sm mx-auto lg:mx-0">{slide.desc}</p>

            {/* Price */}
            <div className="flex items-center gap-4 justify-center lg:justify-start">
              <span className="text-3xl font-black text-yellow-400">{slide.price}</span>
              <div className="text-left">
                <div className="text-sm text-white/50 line-through">{slide.oldPrice}</div>
                <div className="text-xs font-semibold" style={{ color: slide.accent }}>Tiết kiệm {parseInt(slide.discount)}%</div>
              </div>
            </div>

            {/* Features */}
            <div className="flex items-center gap-4 justify-center lg:justify-start text-xs text-white/60">
              <span className="flex items-center gap-1"><Zap size={12} style={{ color: slide.accent }} /> Giao hỏa tốc</span>
              <span className="flex items-center gap-1"><Gift size={12} style={{ color: slide.accent }} /> Quà tặng 500K</span>
              <span className="flex items-center gap-1"><Star size={12} style={{ color: slide.accent }} /> BH 12 tháng</span>
            </div>

            {/* CTAs */}
            <div className="flex items-center gap-3 justify-center lg:justify-start pt-2">
              <button
                className="px-6 py-3 rounded-xl text-white font-bold text-sm transition-all hover:scale-105 btn-pulse shadow-lg"
                style={{ background: "var(--main-color)" }}
              >
                {slide.cta}
              </button>
              <button
                className="px-6 py-3 rounded-xl font-bold text-sm transition-all hover:scale-105 border-2 border-white/30 text-white hover:bg-white/10"
              >
                {slide.ctaSecond}
              </button>
            </div>
          </div>

          {/* Product Image */}
          <div key={`img-${animKey}`} className="flex-1 flex items-center justify-center animate-slide-right">
            <div className="relative">
              <div className="absolute inset-0 rounded-full opacity-20 animate-spin-slow"
                style={{ background: `conic-gradient(${slide.accent}, transparent, ${slide.accent})`, filter: "blur(20px)", scale: "1.3" }} />
              <img
                src={slide.image}
                alt={slide.title}
                className="relative z-10 rounded-2xl object-cover animate-float"
                style={{ width: 380, height: 280, objectFit: "cover", boxShadow: `0 20px 60px rgba(0,0,0,0.5)` }}
              />
              {/* Tag */}
              <div className="absolute -top-3 -right-3 z-20 w-14 h-14 rounded-full flex items-center justify-center text-xs font-black text-white shadow-lg"
                style={{ background: "var(--main-color)" }}>
                {slide.tag}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Prev / Next */}
      <button onClick={prev}
        className="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/10 hover:bg-white/25 text-white flex items-center justify-center transition-all">
        <ChevronLeft size={20} />
      </button>
      <button onClick={next}
        className="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/10 hover:bg-white/25 text-white flex items-center justify-center transition-all">
        <ChevronRight size={20} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-20">
        {slides.map((_, i) => (
          <button key={i} onClick={() => goTo(i)}
            className="transition-all rounded-full"
            style={{
              width: i === current ? 28 : 8,
              height: 8,
              background: i === current ? "var(--main-color)" : "rgba(255,255,255,0.4)",
            }} />
        ))}
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 h-0.5 transition-all duration-[5000ms] ease-linear"
        style={{ width: isPaused ? "0%" : "100%", background: "var(--main-color)" }} />
    </section>
  );
}
