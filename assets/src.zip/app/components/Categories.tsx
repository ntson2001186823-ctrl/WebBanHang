import { ArrowRight } from "lucide-react";

const categories = [
  {
    id: 1,
    name: "Điện thoại",
    count: "1.200+ sản phẩm",
    icon: "📱",
    image: "https://images.unsplash.com/photo-1760900051041-90417b9c110e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    color: "#e31837",
    bg: "#fff5f7",
    hot: true,
  },
  {
    id: 2,
    name: "Laptop",
    count: "850+ sản phẩm",
    icon: "💻",
    image: "https://images.unsplash.com/photo-1668095736209-cb9debc6fada?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    color: "#2563eb",
    bg: "#eff6ff",
    hot: false,
  },
  {
    id: 3,
    name: "Tai nghe",
    count: "650+ sản phẩm",
    icon: "🎧",
    image: "https://images.unsplash.com/photo-1755182529034-189a6051faae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    color: "#7c3aed",
    bg: "#f5f3ff",
    hot: true,
  },
  {
    id: 4,
    name: "Smart TV",
    count: "320+ sản phẩm",
    icon: "📺",
    image: "https://images.unsplash.com/photo-1758577515339-93872db0d37e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    color: "#0891b2",
    bg: "#ecfeff",
    hot: false,
  },
  {
    id: 5,
    name: "Máy ảnh",
    count: "420+ sản phẩm",
    icon: "📷",
    image: "https://images.unsplash.com/photo-1751107996128-6a85dae2a7e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    color: "#d97706",
    bg: "#fffbeb",
    hot: false,
  },
  {
    id: 6,
    name: "Gaming",
    count: "780+ sản phẩm",
    icon: "🎮",
    image: "https://images.unsplash.com/photo-1644571580854-114d7d8fa383?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    color: "#16a34a",
    bg: "#f0fdf4",
    hot: true,
  },
  {
    id: 7,
    name: "Smartwatch",
    count: "280+ sản phẩm",
    icon: "⌚",
    image: "https://images.unsplash.com/photo-1758348844355-2ef28345979d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    color: "#be185d",
    bg: "#fdf2f8",
    hot: false,
  },
  {
    id: 8,
    name: "Phụ kiện",
    count: "2.000+ sản phẩm",
    icon: "🔌",
    image: "https://images.unsplash.com/photo-1766855841547-b4ffef4b98e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    color: "#ea580c",
    bg: "#fff7ed",
    hot: false,
  },
];

export function Categories() {
  return (
    <section className="py-12" style={{ background: "var(--gray-light)", fontFamily: "var(--font-main)" }}>
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-1 h-6 rounded-full" style={{ background: "var(--main-color)" }}></div>
              <span className="text-sm font-semibold" style={{ color: "var(--main-color)" }}>DANH MỤC SẢN PHẨM</span>
            </div>
            <h2 className="font-black" style={{ color: "var(--dark)", fontSize: "1.75rem" }}>
              Khám Phá <span style={{ color: "var(--main-color)" }}>Danh Mục Nổi Bật</span>
            </h2>
          </div>
          <a href="#" className="hidden sm:flex items-center gap-1.5 text-sm font-semibold transition-all hover:gap-3"
            style={{ color: "var(--main-color)" }}>
            Tất cả danh mục <ArrowRight size={16} />
          </a>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {categories.map((cat, index) => (
            <a
              key={cat.id}
              href="#"
              className="category-card bg-white rounded-2xl overflow-hidden cursor-pointer group block"
              style={{
                boxShadow: "var(--shadow)",
                animationDelay: `${index * 0.05}s`,
              }}
            >
              {/* Image */}
              <div className="relative overflow-hidden h-36">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="cat-img w-full h-full object-cover"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                {/* Hot badge */}
                {cat.hot && (
                  <div className="absolute top-2 right-2 badge-hot px-2 py-0.5 rounded-full text-xs font-bold">
                    HOT
                  </div>
                )}
                {/* Icon */}
                <div className="absolute top-2 left-2 text-2xl">{cat.icon}</div>
              </div>

              {/* Info */}
              <div className="p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-sm" style={{ color: "var(--dark)" }}>{cat.name}</div>
                    <div className="text-xs mt-0.5" style={{ color: "var(--gray)" }}>{cat.count}</div>
                  </div>
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center transition-transform group-hover:scale-110"
                    style={{ background: cat.bg }}>
                    <ArrowRight size={14} style={{ color: cat.color }} />
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
