import { Phone, Mail, MapPin, Facebook, Youtube, Instagram, Send, CreditCard, Truck, Shield, RotateCcw, ChevronRight } from "lucide-react";

const footerLinks = {
  "Về TechShop": [
    "Giới thiệu công ty",
    "Tuyển dụng",
    "Tin tức công nghệ",
    "Quan hệ đối tác",
    "Liên hệ chúng tôi",
  ],
  "Chính sách": [
    "Chính sách bảo hành",
    "Chính sách đổi trả",
    "Chính sách vận chuyển",
    "Chính sách bảo mật",
    "Điều khoản sử dụng",
  ],
  "Hỗ trợ khách hàng": [
    "Hướng dẫn mua hàng",
    "Kiểm tra đơn hàng",
    "Thanh toán trả góp",
    "Câu hỏi thường gặp",
    "Trung tâm bảo hành",
  ],
};

const paymentMethods = [
  { name: "Visa", bg: "#1a1f71", text: "VISA" },
  { name: "MasterCard", bg: "#eb001b", text: "MC" },
  { name: "MoMo", bg: "#a50064", text: "MoMo" },
  { name: "VNPay", bg: "#00457c", text: "VNPay" },
  { name: "COD", bg: "#16a34a", text: "COD" },
];

export function Footer() {
  return (
    <footer style={{ fontFamily: "var(--font-main)", background: "#111827", color: "#d1d5db" }}>
      {/* Policy Strip */}
      <div style={{ background: "var(--main-color)" }} className="py-4">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: <Truck size={22} />, title: "Miễn phí vận chuyển", sub: "Đơn hàng từ 500K" },
            { icon: <Shield size={22} />, title: "Bảo hành chính hãng", sub: "12 tháng toàn quốc" },
            { icon: <RotateCcw size={22} />, title: "Đổi trả dễ dàng", sub: "Trong vòng 30 ngày" },
            { icon: <Phone size={22} />, title: "Hỗ trợ 24/7", sub: "Hotline: 1900 1234" },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 text-white">
              <div className="bg-white/20 p-2.5 rounded-lg shrink-0">{item.icon}</div>
              <div>
                <div className="font-semibold text-sm leading-tight">{item.title}</div>
                <div className="text-xs text-white/80">{item.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
        {/* Brand */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center text-white text-2xl font-black"
              style={{ background: "var(--main-color)" }}
            >
              T
            </div>
            <div>
              <div className="text-xl font-black text-white">
                TECH<span style={{ color: "var(--main-color-light)" }}>SHOP</span>
              </div>
              <div className="text-xs text-gray-500">Điện tử chính hãng số 1 Việt Nam</div>
            </div>
          </div>
          <p className="text-sm leading-relaxed text-gray-400">
            TechShop là hệ thống bán lẻ điện tử uy tín, cung cấp các sản phẩm chính hãng với giá tốt nhất thị trường.
            Hơn 200+ cửa hàng trên toàn quốc, phục vụ hàng triệu khách hàng.
          </p>
          {/* Contact */}
          <div className="space-y-2 text-sm">
            {[
              { icon: <MapPin size={15} />, text: "123 Đường Cách Mạng Tháng 8, Q.3, TP.HCM" },
              { icon: <Phone size={15} />, text: "Hotline: 1900 1234 (8:00 - 22:00)" },
              { icon: <Mail size={15} />, text: "support@techshop.vn" },
            ].map((c, i) => (
              <div key={i} className="flex items-start gap-2 text-gray-400">
                <span style={{ color: "var(--main-color-light)" }} className="mt-0.5 shrink-0">{c.icon}</span>
                <span>{c.text}</span>
              </div>
            ))}
          </div>
          {/* Social */}
          <div className="flex items-center gap-3 pt-1">
            {[
              { icon: <Facebook size={18} />, href: "#", bg: "#1877f2" },
              { icon: <Youtube size={18} />, href: "#", bg: "#ff0000" },
              { icon: <Instagram size={18} />, href: "#", bg: "linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888)" },
            ].map((s, i) => (
              <a key={i} href={s.href}
                className="w-9 h-9 rounded-lg flex items-center justify-center text-white transition-opacity hover:opacity-80"
                style={{ background: s.bg }}>
                {s.icon}
              </a>
            ))}
            <a href="#" className="text-xs text-gray-500 hover:text-gray-300 transition-colors">
              Đã thông báo Bộ Công Thương
            </a>
          </div>
        </div>

        {/* Links */}
        {Object.entries(footerLinks).map(([title, links]) => (
          <div key={title}>
            <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-wide relative pl-3"
              style={{ borderLeft: "3px solid var(--main-color)" }}>
              {title}
            </h4>
            <ul className="space-y-2.5">
              {links.map(link => (
                <li key={link}>
                  <a href="#" className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-white transition-colors group">
                    <ChevronRight size={13} style={{ color: "var(--main-color)" }} className="group-hover:translate-x-1 transition-transform" />
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Newsletter + Payment */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Newsletter */}
          <div className="flex items-center gap-3 w-full md:w-auto">
            <div>
              <div className="text-white font-semibold text-sm">Đăng ký nhận ưu đãi</div>
              <div className="text-gray-500 text-xs">Nhận thông báo khuyến mãi mới nhất</div>
            </div>
            <div className="flex overflow-hidden rounded-lg border border-gray-700 ml-2">
              <input
                type="email"
                placeholder="Email của bạn..."
                className="px-3 py-2 bg-gray-800 text-sm text-white placeholder-gray-500 outline-none w-44"
              />
              <button
                className="px-4 text-white flex items-center gap-1 text-sm font-medium transition-opacity hover:opacity-90"
                style={{ background: "var(--main-color)" }}
              >
                <Send size={14} /><span className="hidden sm:block">Đăng ký</span>
              </button>
            </div>
          </div>

          {/* Payment icons */}
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <span className="text-gray-500 text-xs mr-1">Thanh toán:</span>
            {paymentMethods.map(p => (
              <div key={p.name} className="px-2.5 py-1 rounded text-white text-xs font-bold"
                style={{ background: p.bg }}>
                {p.text}
              </div>
            ))}
            <div className="px-2.5 py-1 rounded bg-gray-700 text-white text-xs font-bold flex items-center gap-1">
              <CreditCard size={12} /> ATM
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-gray-800 py-4 text-center text-xs text-gray-600">
        © 2025 TechShop Vietnam. Bản quyền thuộc về TechShop. GPKD: 0123456789 do Sở KH&ĐT TP.HCM cấp.
      </div>
    </footer>
  );
}
