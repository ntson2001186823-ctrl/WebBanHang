import { ShoppingCart, X } from "lucide-react";
import { useCart } from "../context/CartContext";

export function CartToast() {
  const { toasts, setCartOpen } = useCart();

  return (
    <div
      className="fixed bottom-6 right-6 z-[2000] flex flex-col gap-2 pointer-events-none"
      style={{ fontFamily: "var(--font-main)" }}
    >
      {toasts.map((toast, i) => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-center gap-3 bg-white rounded-2xl shadow-2xl border pr-4 overflow-hidden"
          style={{
            borderColor: "var(--border-color)",
            animation: "fadeInUp 0.35s ease forwards",
            maxWidth: 340,
            borderLeft: "4px solid var(--main-color)",
          }}
        >
          {/* Product image */}
          <div className="w-14 h-14 shrink-0 overflow-hidden">
            <img src={toast.image} alt={toast.name} className="w-full h-full object-cover" />
          </div>
          {/* Text */}
          <div className="flex-1 min-w-0 py-3">
            <div className="flex items-center gap-1 text-xs font-semibold mb-0.5" style={{ color: "#16a34a" }}>
              <ShoppingCart size={11} /> Đã thêm vào giỏ hàng!
            </div>
            <div className="text-xs font-semibold line-clamp-2 leading-snug" style={{ color: "var(--dark)" }}>
              {toast.name}
            </div>
          </div>
          {/* View cart */}
          <button
            onClick={() => setCartOpen(true)}
            className="shrink-0 px-2 py-1 rounded-lg text-xs font-bold transition-all hover:opacity-80"
            style={{ background: "var(--main-color)", color: "white" }}
          >
            Xem giỏ
          </button>
        </div>
      ))}
    </div>
  );
}
