import { useState, useEffect, useRef, useMemo } from "react";
import { Search, X, ShoppingCart, Star, TrendingUp, Clock, ArrowRight, SlidersHorizontal } from "lucide-react";
import { useCart } from "../context/CartContext";
import { ALL_PRODUCTS, CATEGORIES, POPULAR_SEARCHES } from "../data/products";

function formatVND(n: number) {
  return n.toLocaleString("vi-VN") + "đ";
}

type SortKey = "relevance" | "price-asc" | "price-desc" | "rating" | "sold";

export function SearchOverlay() {
  const { searchOpen, setSearchOpen, addToCart, setCartOpen } = useCart();
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("Tất cả");
  const [sortBy, setSortBy] = useState<SortKey>("relevance");
  const [recentSearches, setRecentSearches] = useState<string[]>(["iPhone 16", "MacBook", "Tai nghe Sony"]);
  const [showFilters, setShowFilters] = useState(false);
  const [addedIds, setAddedIds] = useState<number[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input when open
  useEffect(() => {
    if (searchOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setQuery("");
      setActiveCategory("Tất cả");
      setSortBy("relevance");
    }
  }, [searchOpen]);

  // ESC to close
  useEffect(() => {
    const fn = (e: KeyboardEvent) => e.key === "Escape" && setSearchOpen(false);
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [setSearchOpen]);

  // Lock scroll
  useEffect(() => {
    document.body.style.overflow = searchOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [searchOpen]);

  const results = useMemo(() => {
    let list = [...ALL_PRODUCTS];

    // Filter by query
    if (query.trim()) {
      const q = query.toLowerCase().trim();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      );
    }

    // Filter by category
    if (activeCategory !== "Tất cả") {
      list = list.filter(p => p.category === activeCategory);
    }

    // Sort
    switch (sortBy) {
      case "price-asc":  list.sort((a, b) => a.price - b.price); break;
      case "price-desc": list.sort((a, b) => b.price - a.price); break;
      case "rating":     list.sort((a, b) => b.rating - a.rating); break;
      case "sold":       list.sort((a, b) => b.sold - a.sold); break;
    }

    return list;
  }, [query, activeCategory, sortBy]);

  const handleSearch = (term: string) => {
    setQuery(term);
    if (term && !recentSearches.includes(term)) {
      setRecentSearches(prev => [term, ...prev].slice(0, 5));
    }
  };

  const handleAddToCart = (product: typeof ALL_PRODUCTS[0]) => {
    addToCart(product);
    setAddedIds(prev => [...prev, product.id]);
    setTimeout(() => setAddedIds(prev => prev.filter(id => id !== product.id)), 1500);
  };

  const handleBuyNow = (product: typeof ALL_PRODUCTS[0]) => {
    addToCart(product);
    setSearchOpen(false);
    setTimeout(() => setCartOpen(true), 200);
  };

  const sortOptions: { key: SortKey; label: string }[] = [
    { key: "relevance",  label: "Liên quan nhất" },
    { key: "sold",       label: "Bán chạy nhất" },
    { key: "rating",     label: "Đánh giá cao" },
    { key: "price-asc",  label: "Giá: Thấp → Cao" },
    { key: "price-desc", label: "Giá: Cao → Thấp" },
  ];

  const isSearching = query.trim().length > 0;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-[1300] transition-opacity duration-300"
        style={{
          background: "rgba(0,0,0,0.6)",
          opacity: searchOpen ? 1 : 0,
          pointerEvents: searchOpen ? "auto" : "none",
          backdropFilter: "blur(4px)",
        }}
        onClick={() => setSearchOpen(false)}
      />

      {/* Panel */}
      <div
        className="fixed top-0 left-0 right-0 z-[1400] bg-white transition-transform duration-300 ease-in-out"
        style={{
          maxHeight: "90vh",
          transform: searchOpen ? "translateY(0)" : "translateY(-100%)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.2)",
          fontFamily: "var(--font-main)",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Search bar */}
        <div className="flex items-center gap-3 px-4 md:px-8 py-4 border-b" style={{ borderColor: "var(--border-color)" }}>
          <Search size={22} style={{ color: "var(--main-color)", shrink: 0 }} />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSearch(query)}
            placeholder="Tìm kiếm điện thoại, laptop, tai nghe, camera..."
            className="flex-1 outline-none text-base bg-transparent"
            style={{ color: "var(--dark)", fontFamily: "var(--font-main)" }}
          />
          {query && (
            <button onClick={() => setQuery("")} className="p-1 rounded-full hover:bg-gray-100 transition-colors">
              <X size={18} style={{ color: "var(--gray)" }} />
            </button>
          )}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-sm transition-all"
            style={{
              borderColor: showFilters ? "var(--main-color)" : "var(--border-color)",
              color: showFilters ? "var(--main-color)" : "var(--gray-dark)",
              background: showFilters ? "var(--main-color-bg)" : "white",
            }}
          >
            <SlidersHorizontal size={14} /> Lọc
          </button>
          <button
            onClick={() => setSearchOpen(false)}
            className="p-2 rounded-xl hover:bg-gray-100 transition-colors"
          >
            <X size={20} style={{ color: "var(--dark)" }} />
          </button>
        </div>

        {/* Filters row */}
        {showFilters && (
          <div className="px-4 md:px-8 py-3 border-b flex items-center gap-3 flex-wrap" style={{ borderColor: "var(--border-color)", background: "#fafafa" }}>
            <span className="text-xs font-semibold" style={{ color: "var(--gray)" }}>Sắp xếp:</span>
            {sortOptions.map(o => (
              <button key={o.key} onClick={() => setSortBy(o.key)}
                className="px-3 py-1 rounded-lg text-xs font-semibold transition-all"
                style={sortBy === o.key
                  ? { background: "var(--main-color)", color: "white" }
                  : { background: "white", color: "var(--gray-dark)", border: "1px solid var(--border-color)" }}>
                {o.label}
              </button>
            ))}
          </div>
        )}

        {/* Categories */}
        <div className="px-4 md:px-8 py-3 border-b flex items-center gap-2 overflow-x-auto scrollbar-none" style={{ borderColor: "var(--border-color)" }}>
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => setActiveCategory(cat)}
              className="px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all shrink-0"
              style={activeCategory === cat
                ? { background: "var(--main-color)", color: "white", boxShadow: "0 2px 8px rgba(227,24,55,0.3)" }
                : { background: "var(--gray-light)", color: "var(--gray-dark)" }}>
              {cat}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="overflow-y-auto flex-1">
          {!isSearching ? (
            // Empty state - show suggestions
            <div className="px-4 md:px-8 py-6 space-y-6">
              {/* Recent searches */}
              {recentSearches.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Clock size={15} style={{ color: "var(--gray)" }} />
                    <span className="text-sm font-bold" style={{ color: "var(--dark)" }}>Tìm kiếm gần đây</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {recentSearches.map(s => (
                      <button key={s} onClick={() => handleSearch(s)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm border transition-all hover:border-red-300 hover:bg-red-50"
                        style={{ borderColor: "var(--border-color)", color: "var(--gray-dark)" }}>
                        <Clock size={11} style={{ color: "var(--gray)" }} /> {s}
                      </button>
                    ))}
                    <button onClick={() => setRecentSearches([])}
                      className="px-3 py-1.5 rounded-full text-xs text-gray-400 hover:text-red-500 transition-colors">
                      Xóa tất cả
                    </button>
                  </div>
                </div>
              )}
              {/* Popular searches */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp size={15} style={{ color: "var(--main-color)" }} />
                  <span className="text-sm font-bold" style={{ color: "var(--dark)" }}>Từ khóa phổ biến</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {POPULAR_SEARCHES.map((s, i) => (
                    <button key={s} onClick={() => handleSearch(s)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm border transition-all hover:border-red-300 hover:bg-red-50"
                      style={{ borderColor: "var(--border-color)", color: "var(--gray-dark)" }}>
                      <span className="text-xs font-black" style={{ color: i < 3 ? "var(--main-color)" : "var(--gray)" }}>
                        {i + 1}
                      </span>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              {/* Featured quick picks */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-bold" style={{ color: "var(--dark)" }}>Sản phẩm nổi bật</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                  {ALL_PRODUCTS.slice(0, 5).map(p => (
                    <QuickProductCard key={p.id} product={p} onAdd={() => handleAddToCart(p)} added={addedIds.includes(p.id)} />
                  ))}
                </div>
              </div>
            </div>
          ) : (
            // Search results
            <div className="px-4 md:px-8 py-4">
              {/* Result count */}
              <div className="flex items-center justify-between mb-4">
                <div className="text-sm" style={{ color: "var(--gray)" }}>
                  Tìm thấy <strong style={{ color: "var(--dark)" }}>{results.length}</strong> sản phẩm cho &nbsp;
                  <strong style={{ color: "var(--main-color)" }}>"{query}"</strong>
                </div>
              </div>

              {results.length === 0 ? (
                <div className="flex flex-col items-center py-16 gap-3">
                  <Search size={48} style={{ color: "var(--gray-light)" }} />
                  <div className="font-bold text-lg" style={{ color: "var(--dark)" }}>Không tìm thấy sản phẩm</div>
                  <div className="text-sm text-center" style={{ color: "var(--gray)" }}>
                    Thử tìm kiếm với từ khóa khác hoặc xem các sản phẩm gợi ý bên dưới
                  </div>
                  <div className="flex flex-wrap gap-2 justify-center mt-2">
                    {POPULAR_SEARCHES.slice(0, 4).map(s => (
                      <button key={s} onClick={() => setQuery(s)}
                        className="px-3 py-1.5 rounded-full text-sm transition-all hover:bg-red-50"
                        style={{ background: "var(--gray-light)", color: "var(--gray-dark)" }}>
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 pb-8">
                  {results.map(p => (
                    <SearchProductCard
                      key={p.id}
                      product={p}
                      query={query}
                      onAdd={() => handleAddToCart(p)}
                      onBuyNow={() => handleBuyNow(p)}
                      added={addedIds.includes(p.id)}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// Small card for featured/quick picks
function QuickProductCard({ product, onAdd, added }: {
  product: typeof ALL_PRODUCTS[0];
  onAdd: () => void;
  added: boolean;
}) {
  return (
    <div className="group bg-white rounded-xl border overflow-hidden cursor-pointer transition-all hover:-translate-y-1"
      style={{ borderColor: "var(--border-color)", boxShadow: "var(--shadow)" }}>
      <div className="h-28 overflow-hidden bg-gray-50">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
      </div>
      <div className="p-2.5 space-y-1">
        <div className="text-xs line-clamp-2 font-semibold leading-snug" style={{ color: "var(--dark)" }}>{product.name}</div>
        <div className="font-black text-xs" style={{ color: "var(--main-color)" }}>{product.price.toLocaleString("vi-VN")}đ</div>
        <button onClick={onAdd}
          className="w-full py-1.5 rounded-lg text-xs font-bold transition-all"
          style={added
            ? { background: "#16a34a", color: "white" }
            : { background: "var(--main-color)", color: "white" }}>
          {added ? "✓ Đã thêm" : "+ Giỏ hàng"}
        </button>
      </div>
    </div>
  );
}

// Full card for search results
function SearchProductCard({ product, query, onAdd, onBuyNow, added }: {
  product: typeof ALL_PRODUCTS[0];
  query: string;
  onAdd: () => void;
  onBuyNow: () => void;
  added: boolean;
}) {
  // Highlight matching text
  const highlight = (text: string) => {
    if (!query.trim()) return text;
    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
    const parts = text.split(regex);
    return parts.map((part, i) =>
      regex.test(part)
        ? <mark key={i} style={{ background: "#fff3cd", color: "var(--dark)", borderRadius: 2, padding: "0 1px" }}>{part}</mark>
        : part
    );
  };

  return (
    <div className="group bg-white rounded-xl border overflow-hidden transition-all hover:-translate-y-1 hover:shadow-lg"
      style={{ borderColor: "var(--border-color)", boxShadow: "var(--shadow)" }}>
      {/* Image */}
      <div className="relative h-36 bg-gray-50 overflow-hidden">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        {product.discount > 0 && (
          <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-full text-xs font-black text-white"
            style={{ background: "var(--main-color)" }}>
            -{product.discount}%
          </div>
        )}
        {product.isNew && (
          <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-full text-xs font-bold bg-blue-500 text-white">
            NEW
          </div>
        )}
      </div>
      {/* Info */}
      <div className="p-2.5 space-y-1.5">
        <div className="text-xs font-semibold" style={{ color: "var(--main-color)" }}>{product.brand}</div>
        <h4 className="text-xs font-semibold line-clamp-2 leading-snug" style={{ color: "var(--dark)" }}>
          {highlight(product.name)}
        </h4>
        {/* Rating */}
        <div className="flex items-center gap-0.5">
          {[1,2,3,4,5].map(i => (
            <Star key={i} size={9}
              fill={i <= Math.round(product.rating) ? "#f59e0b" : "none"}
              stroke={i <= Math.round(product.rating) ? "#f59e0b" : "#d1d5db"} />
          ))}
          <span className="text-xs ml-1" style={{ color: "var(--gray)" }}>({product.reviews})</span>
        </div>
        {/* Price */}
        <div>
          <div className="font-black text-sm" style={{ color: "var(--main-color)" }}>
            {product.price.toLocaleString("vi-VN")}đ
          </div>
          {product.oldPrice > product.price && (
            <div className="text-xs line-through" style={{ color: "var(--gray)" }}>
              {product.oldPrice.toLocaleString("vi-VN")}đ
            </div>
          )}
        </div>
        {/* Buttons */}
        <div className="flex gap-1.5 pt-0.5">
          <button onClick={onAdd}
            className="flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1"
            style={added
              ? { background: "#16a34a", color: "white" }
              : { background: "var(--main-color-bg)", color: "var(--main-color)", border: "1px solid var(--main-color)" }}>
            {added ? (
              <><span>✓</span> Đã thêm</>
            ) : (
              <><ShoppingCart size={11} /> Giỏ hàng</>
            )}
          </button>
          <button onClick={onBuyNow}
            className="flex-1 py-1.5 rounded-lg text-xs font-bold text-white transition-opacity hover:opacity-90 flex items-center justify-center gap-1"
            style={{ background: "var(--main-color)" }}>
            <ArrowRight size={11} /> Mua ngay
          </button>
        </div>
      </div>
    </div>
  );
}
