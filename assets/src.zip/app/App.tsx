import "../styles/electronics.css";
import { CartProvider } from "./context/CartContext";
import { Header } from "./components/Header";
import { BannerSlider } from "./components/BannerSlider";
import { Categories } from "./components/Categories";
import { FlashSale } from "./components/FlashSale";
import { FeaturedProducts } from "./components/FeaturedProducts";
import { PromoSection } from "./components/PromoSection";
import { Testimonials } from "./components/Testimonials";
import { Footer } from "./components/Footer";
import { CartDrawer } from "./components/CartDrawer";
import { SearchOverlay } from "./components/SearchOverlay";
import { CartToast } from "./components/CartToast";

function HomePage() {
  return (
    <div style={{ fontFamily: "var(--font-main)", minHeight: "100vh", background: "var(--gray-light)" }}>
      {/* ============================================
          HEADER — Tích hợp giỏ hàng & tìm kiếm
          ============================================ */}
      <Header />

      {/* ============================================
          TRANG CHỦ
          ============================================ */}
      <main>
        <BannerSlider />
        <FlashSale />
        <Categories />
        <FeaturedProducts />
        <PromoSection />
        <Testimonials />
      </main>

      {/* ============================================
          FOOTER
          ============================================ */}
      <Footer />

      {/* ============================================
          OVERLAYS & DRAWERS
          ============================================ */}
      {/* Cart sidebar (trượt từ phải) */}
      <CartDrawer />

      {/* Search overlay (trượt từ trên) */}
      <SearchOverlay />

      {/* Toast notification khi thêm vào giỏ */}
      <CartToast />
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <HomePage />
    </CartProvider>
  );
}
